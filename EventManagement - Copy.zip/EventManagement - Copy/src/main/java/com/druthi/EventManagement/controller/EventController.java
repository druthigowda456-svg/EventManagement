package com.druthi.EventManagement.controller;

import org.springframework.web.bind.annotation.*;

import com.druthi.EventManagement.entity.EventEntity;
import com.druthi.EventManagement.service.EventService;

import java.util.List;

@RestController
@RequestMapping("/api/events")
public class EventController {

    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @PostMapping
    public EventEntity createEvent(@RequestBody EventEntity event) {
        return eventService.saveEvent(event);
    }

    @GetMapping
    public List<EventEntity> getAllEvents() {
        return eventService.getAllEvents();
    }
}
