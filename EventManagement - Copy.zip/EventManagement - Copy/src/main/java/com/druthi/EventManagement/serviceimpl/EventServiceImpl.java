package com.druthi.EventManagement.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.druthi.EventManagement.entity.EventEntity;
import com.druthi.EventManagement.repository.EventRepository;
import com.druthi.EventManagement.service.EventService;

@Service
public class EventServiceImpl implements EventService {

    private final EventRepository eventRepository;

    public EventServiceImpl(EventRepository eventRepository) {
        this.eventRepository = eventRepository;
    }

    @Override
    public EventEntity saveEvent(EventEntity event) {
        return eventRepository.save(event);
    }

    @Override
    public List<EventEntity> getAllEvents() {
        return eventRepository.findAll();
    }

    @Override
    public EventEntity getEventById(Long id) {
        return eventRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Event not found with id " + id));
    }

    @Override
    public EventEntity updateEvent(Long id, EventEntity updatedEvent) {
        EventEntity existingEvent = getEventById(id);
        existingEvent.setName(updatedEvent.getName());
        existingEvent.setLocation(updatedEvent.getLocation());
        existingEvent.setDescription(updatedEvent.getDescription());
        return eventRepository.save(existingEvent);
    }

    @Override
    public void deleteEvent(Long id) {
        eventRepository.deleteById(id);
    }
}
