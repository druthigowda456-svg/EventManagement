package com.druthi.EventManagement.service;

import java.util.List;
import com.druthi.EventManagement.entity.EventEntity;

public interface EventService {
    EventEntity saveEvent(EventEntity event);

    List<EventEntity> getAllEvents();

    EventEntity getEventById(Long id);

    EventEntity updateEvent(Long id, EventEntity updatedEvent);

    void deleteEvent(Long id);
}
